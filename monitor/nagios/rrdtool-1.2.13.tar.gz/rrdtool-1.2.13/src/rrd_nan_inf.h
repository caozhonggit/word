#define DNAN          set_to_DNAN()
#define DINF          set_to_DINF()

double set_to_DNAN(void);
double set_to_DINF(void);
