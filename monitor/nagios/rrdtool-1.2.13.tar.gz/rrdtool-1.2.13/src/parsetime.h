#ifndef __PARSETIME_H__
#define __PARSETIME_H__

#include <stdio.h>

#include "rrd.h"

#endif
